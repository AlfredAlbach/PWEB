// Recebe os dois números
const numero1 = parseFloat(prompt("Digite o primeiro número:"));
const numero2 = parseFloat(prompt("Digite o segundo número:"));

// Calcula as operações
const soma = numero1 + numero2;
const subtracao = numero1 - numero2;
const produto = numero1 * numero2;
const divisao = numero1 / numero2; //
const resto = numero1 % numero2;

alert(
    "\nSoma: " + soma +
    "\nSubtração: " + subtracao +
    "\nProduto: " + produto +
    "\nDivisão: " + divisao +
    "\nResto: " + resto
); //KKKKKKKKKKKKKK MT ENGRAÇADO ISSO SLK