document.write("Acabou hahaha");
const nome = prompt("Digite o nome do aluno : ");

const nota1 = parseFloat(prompt("Digite a primeira nota:"));
const nota2 = parseFloat(prompt("Digite a segunda nota:"));
const nota3 = parseFloat(prompt("Digite a terceira nota:"));
const nota4 = parseFloat(prompt("Digite a quarta nota:"));
//parseFloat transforma o texto digitado em numero

const media = (nota1 + nota2 + nota3 + nota4) / 4;

alert("Aluno: " + nome + "\nMédia: " + media.toFixed(2));
alert("Aluno:   ${nome}  \nMédia:  ${media.toFixed(2)}");